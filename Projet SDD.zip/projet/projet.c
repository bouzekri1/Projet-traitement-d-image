
                                                          

                                                             // Projet réalisé par Bouzekri Abdessmad et Domingo Cédric



#include <stdio.h>
#include <stdlib.h>
#include "lodepng.h"
#include <stdint.h>
#include <assert.h>
#include <time.h>

typedef struct { 
  uint32_t longueur;
  uint32_t largeur ;
  unsigned char **rouge;
}image;
typedef struct {
    uint32_t i;
    uint32_t j;
    unsigned char pix;
    unsigned char pixgrad;
}pixel;

typedef struct _maillon{
  pixel p;
  struct _maillon *suivant;
}maillon;

typedef struct
{
 uint32_t taille;
 maillon *tete;
 maillon *queue;
} liste;

image AllouerImage(uint32_t , uint32_t );
image LireImage(const char * );
void LibererImage(image );
void EcrireImage(image ,char * );
void EcrireImageCoul(image ,char * );
image CalculGradient(image ,uint32_t );
liste *new_liste();
void printList(maillon *start);

void add_tete(liste *l, uint32_t i,uint32_t j,unsigned char pi,unsigned char pg);
maillon *new_maillon(uint32_t i,uint32_t j,unsigned char pi,unsigned char pg);
image calculerLPE(image gradient,image m);
void Tri(maillon *start);
void swap(maillon *a, maillon *b);
_Bool est_vide( liste *l );
void rem_tete(liste *l);
void contour(image m,image gradient,image orig);
void EcrireImageCont(image im,char * nom);


int main(int argc, char const *argv[]) {
  srand(time(NULL));
  image im1,im;
  im1 =LireImage("route.png") ; //test de fonction
  im=LireImage("route_marqueurs.png"); //test de fonction
  //EcrireImage(im,"avion_test.png");//test fonction
  //im=AllouerImage(im,4,3);  //test de fonction
  image grad=CalculGradient(im1,1); //test foction
	calculerLPE(grad,im); //test de fonction
  //LibererImage(im); //test de fonction
  contour(im,grad,im1); //test de fonction



  return EXIT_SUCCESS;
}

image LireImage(const char * nom)
{
  image im;
  uint32_t erreur,larg,hauteur,k;
  unsigned char* tab;

  erreur=lodepng_decode32_file(&tab,&larg,&hauteur,nom);
  if(erreur)
  {
    printf("erreur lors de la lecture de l'image");
    exit(EXIT_FAILURE);
  }
  im.longueur=hauteur;
  im.largeur=larg;
  im.rouge=malloc(hauteur*sizeof(unsigned char*));
  for(int32_t j=0;j<hauteur;j++)
  {
    im.rouge[j]=malloc(larg*sizeof(unsigned char));
  }
  k=0;
  for (int32_t i=0;i<hauteur;i++)
  {
    for(int32_t j=0;j<larg;j++)
    {
      im.rouge[i][j]=tab[k];
      k=k+4;
    }
  }
  free(tab);
  return im;
}

void EcrireImage(image im,char * nom)
{
  int32_t erreur,k=0;
  char *tab=malloc(4*im.longueur*im.largeur*sizeof(char)); //tableau intermediaire pour y mettre les pixels
  for(int32_t i=0;i<im.longueur;i++)
  {
    for(int32_t j=0;j<im.largeur;j++)
    {
      //on ajoute les pixels dans le tableau
      tab[k]=im.rouge[i][j];
      tab[k+1]=im.rouge[i][j];
      tab[k+2]=im.rouge[i][j];
      tab[k+3]=255; //transparence
      k=k+4;
    }
  }
  erreur=lodepng_encode32_file(nom,tab,im.largeur,im.longueur); //encodage de l'image
  //on verifie si l'image s'est bien encodée
  if(erreur)
  {
    printf("erreur lors de l'encodage");
    exit(EXIT_FAILURE);
  }
  //on libere de la memoire le tableau intermediaire
  free(tab);
}


image AllouerImage(uint32_t hauteur,uint32_t largeur)
{
       image im;
       im.rouge=malloc(hauteur*sizeof(unsigned char * ));
  im.longueur=hauteur;
  im.largeur=largeur;
  for(int32_t j=0;j<hauteur;j++){
        im.rouge[j]=malloc(largeur*sizeof(unsigned char ));
  }
  //initialisation de tout les pixels à 0
  for(int32_t i=0;i<im.longueur;i++){
        for(int32_t j=0;j<im.largeur;j++){
              im.rouge[i][j]=0;
        }
  }
  return im;
}


void LibererImage(image im)
{
  for(int32_t i=0;i<im.longueur;i++)
  {
    free(im.rouge[i]);
  }
  free(im.rouge);
}


image CalculGradient(image im,uint32_t r){
      image grad;
      grad=AllouerImage(im.longueur,im.largeur);//on construit le tableau
      unsigned char max,min;
      for(int32_t i=0;i<grad.longueur;i++)
      {
        for(int32_t j=0;j<grad.largeur;j++)
        {
          max=im.rouge[i][j]; //initialisation
          min=im.rouge[i][j];//initialisation
          
          for(int32_t k=i-r;k<i+r+1;k++) //on cherche autour du pixel avec un rayon r la valeur min et max
          {
            for(int32_t l=j-r;l<j+r+1;l++)
            {
              if((k>=0)&&(k<grad.longueur)&&(l>=0)&&(l<grad.largeur)) //on verifie les bords
              {

                if(im.rouge[k][l]>max)
                {
                  max=im.rouge[k][l];
                }
                              
                if(im.rouge[k][l]<min)
                {
                  min=im.rouge[k][l];
                }
              }
            }
          }
          grad.rouge[i][j]=max-min;
        }
      }

     EcrireImage(grad,"gradient.png"); //on reconstruit l'image
    return grad;
}


// PARTIE 4

/*ici j'utilise une liste qui contiendra des structures pixel, la liste est triée par
la methode du tri à bulle par ordre croissant,la tete de liste contiendra la plus
petite valeur du pixel du gradient*/
/*fonctions classiques de manipulation de liste*/
liste *new_liste()
{
 liste *r = malloc(sizeof(liste));
 if(r==NULL)
 {
   assert(0);
 }
 r->taille=0;
 r->tete = NULL;
 r->queue = NULL;
 return r;
}

void add_tete(liste *l, uint32_t i,uint32_t j,unsigned char pi,unsigned char pg)
{
 maillon *m = new_maillon(i,j,pi,pg);
 m->suivant = l->tete;
 l->tete = m;
 if( l->taille == 0 )
 {
   l->queue = m;
 }
 l->taille += 1;

}
void rem_tete(liste *l)
{
	if(est_vide(l))
	{
		printf("la tete de liste ne peut etre supprimee car la liste est vide");
		return;
	}
 maillon *t = l->tete;
 l->tete = l->tete->suivant;
 free(t);
 l->taille -= 1;
 if( l->taille == 0 )
 {
 	l->queue = NULL;
 }
}
maillon *new_maillon(uint32_t i,uint32_t j,unsigned char pi,unsigned char pg)
{
  maillon *m = malloc(sizeof(maillon));
 if(m==NULL)
 {
   assert(0);
 }
 m->p.i = i;
 m->p.j=j;
 m->p.pix=pi;
 m->p.pixgrad=pg;
 return m;
}

image calculerLPE(image gradient,image m)
{
	liste *l=new_liste();
	uint32_t i,j;
	for (uint32_t i=0;i<m.longueur;i++)
	{
		for(uint32_t j=0;j<m.largeur;j++)
		{
			if(m.rouge[i][j]!=0) //le pixel est different de 0, on l'insere dans la liste
			{
				add_tete(l,i,j,m.rouge[i][j],gradient.rouge[i][j]); //on insere dans l tout les pixels differents de 0 en utilisant la structure pixel
			}
		}
	}
	Tri(l->tete); //on trie la liste par ordre croissant en fonction de la valeur du pixel de l'image gradient
	//printList(l->tete); //fonction test
	while(!(est_vide(l))) //on commence à construire la ligne de partage
	{
		int32_t i=l->tete->p.i;
		int32_t j=l->tete->p.j;
		rem_tete(l);
		for(int32_t ii=i-1;(ii<i+2) && (ii<m.longueur) && (ii>=0);ii++)
		{
			for (int32_t jj=j-1;(jj<j+2) && (jj<m.largeur) &&(jj>=0);jj++)
			{
				if(m.rouge[ii][jj]==0)
				{
					m.rouge[ii][jj]=m.rouge[i][j];//le pixel sera different de 0
					add_tete(l,ii,jj,m.rouge[ii][jj],gradient.rouge[ii][jj]); //on rajoute ce pixel
					Tri(l->tete); //tri de la liste,
				}
			}
		}
	}
	EcrireImageCoul(m,"route_res.png");//on reconstruit l'image
  return m;
}


_Bool est_vide( liste *l )
{
 return l->taille == 0;
}

void printList(maillon *start)
{
    maillon *temp = start;
    printf("\n");
    while (temp!=NULL)
    {
        printf("pix grad =%d pix m=%d", temp->p.pixgrad,temp->p.pix);
        temp = temp->suivant;
    }
}
void Tri(maillon *start)
{
    int32_t swapped, i;
    maillon *ptr1;
    maillon *lptr = NULL;

    /* liste vide */
    if (start == NULL)
		{
			printf("liste vide \n");
    	return ;
  	}
    do
    {
        swapped = 0;
        ptr1 = start; //on se place en tete de liste

        while (ptr1->suivant != lptr) //on n'est pas en queue de liste
        {
            if (ptr1->p.pixgrad > ptr1->suivant->p.pixgrad) //on compare les deux maillons
            {
                swap(ptr1, ptr1->suivant);//on echange les deux maillons
                swapped = 1; //element echangé
            }
            ptr1 = ptr1->suivant;
        }
       
    }
    while (swapped);
}

//fonction intermediaire pour echanger deux maillons
void swap(maillon *a, maillon *b)
{
    pixel temp = a->p;
    a->p = b->p;
    b->p = temp;
}

//PARTIE 5

/*1)pour detecter plusieurs objets dans une image, on ne change pas la fonction
calculer LPE, il suffit d'avoir une image marqueur avec des marqueurs de couleurs
differentes,(plusieurs nuances de gris par ex)*/

//2)algorithme de la representation du resultat de l'algo CalculerLPE en couleur:

void EcrireImageCoul(image im,char * nom)
{
  int32_t erreur,k=0;
  unsigned char v=rand()%255,b=rand()%255; //on tire aleatoirement un nombre entre 0 et 255, ca sera le pixel a utiliser
  char *tab=malloc(4*im.longueur*im.largeur*sizeof(char)); //tableau intermediaire pour stocker les valeurs des differents pixels
//parcours de l'image
  for(int32_t i=0;i<im.longueur;i++)
  {
    for(int32_t j=0;j<im.largeur;j++)
    {
      //canal rgb
      tab[k]=im.rouge[i][j];
      tab[k+1]=v;
      tab[k+2]=b;
      tab[k+3]=255;
      k=k+4;
    }
  }
  //encodage de la photo
  erreur=lodepng_encode32_file(nom,tab,im.largeur,im.longueur);
//verification du bon deroulement de l'encodage
  if(erreur)
  {
    printf("erreur lors de l'encodage");
    exit(EXIT_FAILURE);
  }
  //on libere de la memoire le tableau intermediaire
  free(tab);
}

//3) ressortir les contours de l'image

void contour(image m,image gradient,image orig)
{
  int32_t i,j;
  image im=calculerLPE(gradient,m);//image de la ligne de partage des eaux
  //liste qui contiendra les pixels de la ligne de partage
  liste *l=new_liste();
  for(i=0;i<m.longueur-1;i++)
  {
    for(j=0;j<m.largeur-1;j++)
    {
      /*on verifie la diagonale ,les elements a droite et en basde chaque pixel visité,
      c'est suffisant car l'image est parcourue de gauche à droite et de haut en bas*/
      if ((m.rouge[i][j]!=m.rouge[i+1][j+1])||(m.rouge[i][j]!=m.rouge[i+1][j])||(m.rouge[i][j]!=m.rouge[i][j+1]))
      {
        //on ajoute a la liste les coordonnées du pixel sur la ligne de partage
        add_tete(l,i,j,255,1);
      }
    }
  }
  /*on remplace la valeur du pixel sur la ligne de partage  */
  while(!(est_vide(l)))
  {
    i=l->tete->p.i;
    j=l->tete->p.j;
    orig.rouge[i][j]=300;/*valeur choisis arbitrairement: ca sera une condition dans la fonction ecrire image pour dessiner le trait rouge*/
    rem_tete(l);
  }
  //ecriture de l'image
  EcrireImageCont(orig,"route_cont.png");
}
//fonction pour ecrire l'image, similaire a celle de la partie 2 avec une condition en plus
void EcrireImageCont(image im,char * nom)
{
  int32_t erreur,k=0;
  char *tab=malloc(4*im.longueur*im.largeur*sizeof(char));
  for(int32_t i=0;i<im.longueur;i++)
  {
    for(int32_t j=0;j<im.largeur;j++)
    {
      // il s'agit bien d'un pixel sur la ligne de partage
      if (im.rouge[i][j]==300)
      {
        tab[k]=0;
        tab[k+1]=0;
        tab[k+2]=255;
        tab[k+3]=255;
        k=k+4;
      }
      tab[k]=im.rouge[i][j];
      tab[k+1]=im.rouge[i][j];
      tab[k+2]=im.rouge[i][j];
      tab[k+3]=255;
      k=k+4;
    }
  }
  erreur=lodepng_encode32_file(nom,tab,im.largeur,im.longueur);
  if(erreur)
  {
    printf("erreur lors de l'encodage");
    exit(EXIT_FAILURE);
  }
  free(tab);
}








